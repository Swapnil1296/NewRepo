import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button, Modal } from "react-bootstrap";

import { useSelector } from "react-redux";

const FormOne = () => {
  const [show, setShow] = useState(false);
  const [data, setData] = useState([]);
  const [valueForHolder, setValueForHolder] = useState("")
  const Token = useSelector((state) => state.Auth);
//   console.log("Auth in FormOne:-", Token);
  const handleData = () => {
    axios
      .get(
        `https://alkemapi.indusnettechnologies.com/api/distributor/distributor_list/E?dn=&page_no=${1}`,
        {
          headers: { Authorization: `Bearer ${Token}` },
        }
      )
      .then(function (response) {
        // console.log("response data in formOne:-", response.data);
        setData(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  
   
//   console.log("data in useState:-", data.data);
  const handleClose = (e) => {setShow(false);
    console.log("handleClose:-",e);
};
  const handleShow = () => {
    setShow(true);
    handleData();
  };
 const handleChangedValue =(e)=>{
    console.log("targeted value:-",e.target.value);
    setValueForHolder(e.target.value);
 }
  return (
    <>
      <h1>FormOne</h1>
      <div className="making_btn">
        <input
          type="text"
          //   placeholder={valueForHolder}
          value={valueForHolder}
          onClick={handleShow}
        />
      </div>
      {/* Modal start here */}

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Select Distributor</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input
            type="text"
            placeholder="Search Your Distributor"
            style={{ width: "100%" }}
          />
          {data.data &&
            data.data.map((item, i) => (
              <div>
                <input
                  type="checkbox"
                  id="vehicle1"
                  name="vehicle1"
                  value={item.customer_name}
                  onChange={handleChangedValue}
                  onClick={(e) => handleClose(item.customer_code)}
                  className="roundCheckbox"
                />
                <label for="vehicle1" style={{ margin: "5px" }}>
                  {item.customer_name}-{item.customer_code}-
                  <span>({item.location})</span>
                </label>
                <hr></hr>
              </div>
            ))}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default FormOne;
